

function wkflow_app {
    & {
        C:\Users\adamj\AppData\Local\pypoetry\Cache\virtualenvs\matflow-new-NCbz_a5w-py3.10\Scripts\python.exe "C:\Users\adamj\AppData\Local\pypoetry\Cache\virtualenvs\matflow-new-NCbz_a5w-py3.10\Scripts\matflow" `
            --with-config log_file_path "$pwd/matflow.log" `
            --config-dir "C:\Users\adamj\.matflow-new" `
            --config-key "default" `
            $args
    } @args
}

function get_nth_line($file, $line) {
    Get-Content $file | Select-Object -Skip $line -First 1
}

function JoinMultiPath {
    $numArgs = $args.Length
    $path = $args[0]
    for ($i = 1; $i -lt $numArgs; $i++) {
        $path = Join-Path $path $args[$i]
    }
    return $path
}

function StartJobHere($block) {
    $jobInitBlock = [scriptblock]::Create(@"
        Function wkflow_app { $function:wkflow_app }
        Function get_nth_line { $function:get_nth_line }
        Function JoinMultiPath { $function:JoinMultiPath }
        Set-Location '$pwd'
"@)
    Start-Job -InitializationScript $jobInitBlock -Script $block
}

$WK_PATH = $(Get-Location)
$WK_PATH_ARG = $WK_PATH
$SUB_IDX = 0
$JS_IDX = 0
$EAR_ID_FILE = JoinMultiPath $WK_PATH artifacts submissions $SUB_IDX js_0_EAR_IDs.txt
$ELEM_RUN_DIR_FILE = JoinMultiPath $WK_PATH artifacts submissions $SUB_IDX js_0_run_dirs.txt


for ($JS_elem_idx = 0; $JS_elem_idx -lt 1; $JS_elem_idx += 1) {
    $elem_EAR_IDs = get_nth_line $EAR_ID_FILE $JS_elem_idx
    $elem_run_dirs = get_nth_line $ELEM_RUN_DIR_FILE $JS_elem_idx

    for ($JS_act_idx = 0; $JS_act_idx -lt 1; $JS_act_idx += 1) {

        $EAR_ID = ($elem_EAR_IDs -split ":")[$JS_act_idx]
        if ($EAR_ID -eq -1) {
            continue
        }

        $run_dir = ($elem_run_dirs -split ":")[$JS_act_idx]
        $run_dir_abs = "$WK_PATH\$run_dir"
        Set-Location $run_dir_abs
        $app_stream_file = "$pwd/matflow_std.txt"

        $skip = wkflow_app internal workflow $WK_PATH get-ear-skipped $EAR_ID 2>> $app_stream_file
        $exc_sk = $LASTEXITCODE

        if ($exc_sk -eq 0) {

            if ($skip -eq "1") {
                continue
            }

            wkflow_app internal workflow $WK_PATH write-commands $SUB_IDX $JS_IDX $JS_act_idx $EAR_ID 2>&1 >> $app_stream_file
            $exc_wc = $LASTEXITCODE

            wkflow_app internal workflow $WK_PATH set-ear-start $EAR_ID 2>&1 >> $app_stream_file
            $exc_se = $LASTEXITCODE

            if (($exc_wc -eq 0) -and ($exc_se -eq 0)) {
                . (Join-Path $run_dir_abs "js_0_act_${JS_act_idx}.ps1")
                $exit_code = $LASTEXITCODE
            }
            else {
                $exit_code = If ($exc_wc -ne 0) {$exc_wc} Else {$exc_se}
            }
        }
        else { 
            $exit_code = $exc_sk
        }
        $global:LASTEXITCODE = $null
        wkflow_app internal workflow $WK_PATH set-ear-end $JS_IDX $JS_act_idx $EAR_ID $exit_code 2>&1 >> $app_stream_file

    }

}
Set-Location $WK_PATH
